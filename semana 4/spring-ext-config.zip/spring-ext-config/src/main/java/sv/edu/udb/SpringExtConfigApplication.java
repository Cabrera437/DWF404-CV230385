package sv.edu.udb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringExtConfigApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringExtConfigApplication.class, args);
	}

}
